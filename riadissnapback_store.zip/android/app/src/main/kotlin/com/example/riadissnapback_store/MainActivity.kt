package com.example.riadissnapback_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
