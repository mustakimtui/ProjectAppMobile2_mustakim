import 'package:flutter/material.dart';
import 'package:riadissnapback_store/ui/home.dart';


void main(List<String> args) {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    )
  );
}
